<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>@default</name>
    <message>
        <location filename="../test/test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation type="unfinished">Goedemorgen</translation>
    </message>
</context>
<context>
    <name>GoogleLocatorConfig</name>
    <message>
        <location filename="../locatorfilters/base_api_key_dialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished">Dialoog</translation>
    </message>
    <message>
        <location filename="../locatorfilters/base_api_key_dialog.ui" line="20"/>
        <source>Please provide an Api Key for this service</source>
        <translation type="unfinished">Deze service heeft een api-sleutel nodig</translation>
    </message>
    <message>
        <location filename="../locatorfilters/base_api_key_dialog.ui" line="33"/>
        <source>Api Key</source>
        <translation type="unfinished">Api Sleutel</translation>
    </message>
</context>
<context>
    <name>PdokFilter</name>
    <message>
        <location filename="../locatorfilters/pdoklocatieserver.py" line="16"/>
        <source>PDOK Locatieserver</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
